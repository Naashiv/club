export function initForms(){
  document.querySelectorAll('form[data-validate]').forEach(form=>{
    const errorEl = form.querySelector('[data-error]');
    form.addEventListener('submit',(e)=>{
      const fields = [...form.querySelectorAll('[required]')];
      let ok=true, first=null;
      fields.forEach(f=>{
        const bad = !f.value.trim() || (f.type==='email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.value));
        f.classList.toggle('error', bad); if(bad){ ok=false; first=first||f; }
      });
      if(!ok){ e.preventDefault(); if(errorEl) errorEl.textContent='Please fill all fields correctly.'; first?.focus(); }
      else if(errorEl) errorEl.textContent='';
    });
  });
}
