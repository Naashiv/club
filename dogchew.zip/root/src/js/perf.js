export function boostPerf(){
  // Passive scroll/touch for smoother scrolling
  ['scroll','touchstart','touchmove','wheel'].forEach(ev=>{
    window.addEventListener(ev, ()=>{}, {passive:true});
  });
  // Will-change hints for animated elements
  document.querySelectorAll('[data-will]').forEach(el=>{ el.style.willChange = el.dataset.will; });
}
