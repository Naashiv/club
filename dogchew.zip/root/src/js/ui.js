export function mountHeaderFooter(){
  // If using server-side includes, this is not needed; else fetch partials if desired.
  // Here we assume pages include partials statically.
}
export function imageLQIP(img){
  // If data-lqip is set, fade to full-res on load
  const full = img.getAttribute('src');
  const lq = img.dataset.lqip;
  if(!lq) return;
  img.src = lq;
  const hi = new Image(); hi.src = full;
  hi.onload = ()=>{ img.src = full; img.style.transition='filter .4s'; img.style.filter='blur(0)'; };
}
export function cardToProductTransition(cardEl){
  // Capture card bounds and animate to product hero for page-change illusion
  const rect = cardEl.getBoundingClientRect();
  const clone = cardEl.cloneNode(true);
  clone.style.position='fixed'; clone.style.margin='0'; clone.style.left=rect.left+'px'; clone.style.top=rect.top+'px';
  clone.style.width=rect.width+'px'; clone.style.height=rect.height+'px'; clone.style.zIndex=9999; clone.style.pointerEvents='none';
  document.body.appendChild(clone);
  requestAnimationFrame(()=>{
    clone.style.transition='all .55s cubic-bezier(.2,.8,.2,1)';
    clone.style.left = '50%'; clone.style.top = '16%'; clone.style.transform='translateX(-50%) scale(1.2)';
    clone.style.opacity='0.0';
    setTimeout(()=>{ clone.remove(); }, 600);
  });
}
