// js/cart.js — shared cart state + cart page renderer

(function(){
  const STORAGE_KEY = 'tmart_cart_v3';

  // Utilities
  const fmt = (n) => `$${(Number(n) || 0).toFixed(2)} CAD`;
  function safe(fn, fallback){
    try { return fn(); } catch(e){ return fallback; }
  }

  // Core cart
  const Cart = {
    state: safe(() => JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'), {}),
    save(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state)); },
    add(id, qty=1, product={}){
      if (!id) return;
      const item = this.state[id] || { id, qty: 0, product: product || {} };
      item.qty += qty;
      if (item.qty < 1) item.qty = 1;
      // Keep the latest product fields (e.g., price updates)
      item.product = { ...(item.product||{}), ...(product||{}) };
      this.state[id] = item;
      this.save();
    },
    setQty(id, qty){
      if (!this.state[id]) return;
      const q = Math.max(0, Math.floor(qty || 0));
      if (q === 0) { delete this.state[id]; }
      else { this.state[id].qty = q; }
      this.save();
    },
    remove(id){ if (this.state[id]) { delete this.state[id]; this.save(); } },
    clear(){ this.state = {}; this.save(); },
    count(){ return Object.values(this.state).reduce((n, i) => n + (i.qty || 0), 0); },
    items(){ return Object.values(this.state); },
    subtotal(){
      return this.items().reduce((sum, i) => sum + (i.product?.price || 0) * (i.qty || 0), 0);
    }
  };

  // Badge updater
  function updateBadge(){
    const badge = document.querySelector('[data-cart-count]');
    const c = Cart.count();
    if (badge) {
      badge.textContent = c;
      badge.style.display = c > 0 ? 'inline-flex' : 'none';
    }
  }

  // Expose to global
  window.Tmart = window.Tmart || {};
  window.Tmart.cart = Cart;
  window.Tmart.updateCartBadge = updateBadge;

  // Keep badge in sync on page load
  document.addEventListener('DOMContentLoaded', updateBadge);

  // Cart Page Controller
  const cartPage = {
    taxRate: 0.13, // Adjust based on region if needed
    els: {},

    init(){
      this.cacheEls();
      this.render();
      this.bind();
    },

    cacheEls(){
      this.els.section = document.getElementById('cartSection');
      this.els.empty = document.getElementById('cartEmpty');
      this.els.content = document.getElementById('cartContent');
      this.els.tbody = document.getElementById('cartTableBody');
      this.els.subtotal = document.getElementById('sumSubtotal');
      this.els.tax = document.getElementById('sumTax');
      this.els.total = document.getElementById('sumTotal');
      this.els.btnClear = document.getElementById('btnClearCart');
      this.els.btnCheckout = document.getElementById('btnCheckout');
    },

    bind(){
      if (this.els.btnClear) {
        this.els.btnClear.addEventListener('click', () => {
          if (confirm('Clear all items from your cart?')) {
            Cart.clear();
            updateBadge();
            this.render();
          }
        });
      }
      if (this.els.tbody) {
        this.els.tbody.addEventListener('input', (e) => {
          const input = e.target.closest('input[data-id]');
          if (!input) return;
          const id = input.dataset.id;
          const qty = parseInt(input.value, 10);
          Cart.setQty(id, isNaN(qty) ? 1 : qty);
          updateBadge();
          this.render();
        });
        this.els.tbody.addEventListener('click', (e) => {
          const btn = e.target.closest('button[data-remove]');
          if (!btn) return;
          const id = btn.dataset.remove;
          Cart.remove(id);
          updateBadge();
          this.render();
        });
      }
      if (this.els.btnCheckout) {
        this.els.btnCheckout.addEventListener('click', () => {
          // Stub: integrate with your checkout provider here
          alert('Proceeding to checkout... (Integrate your checkout provider here)');
        });
      }
    },

    render(){
      const items = Cart.items();
      const hasItems = items.length > 0;

      if (this.els.empty) this.els.empty.style.display = hasItems ? 'none' : 'block';
      if (this.els.content) this.els.content.style.display = hasItems ? 'block' : 'none';

      if (!hasItems) return;

      // Build rows
      const rows = items.map(i => {
        const p = i.product || {};
        const name = p.name || 'Yak Chew';
        const img = (p.images && p.images[0]) ? p.images[0] : 'assets/images/placeholder.jpg';
        const price = Number(p.price || 0);
        const qty = Number(i.qty || 1);
        const line = price * qty;
        const heritage = p.heritage || '';
        const features = Array.isArray(p.features) ? p.features : [];

        return `
          <tr>
            <td>
              <div style="display:flex; gap:.8rem; align-items:center">
                <img src="${img}" alt="${name}" width="64" height="64" style="border-radius:8px; object-fit:cover">
                <div>
                  <strong>${name}</strong>
                  ${heritage ? `<div class="muted" style="font-size:.85rem">${heritage}</div>` : ''}
                  ${features.length ? `<div class="muted" style="font-size:.75rem">${features.slice(0,2).join(' • ')}</div>` : ''}
                </div>
              </div>
            </td>
            <td>${fmt(price)}</td>
            <td>
              <input type="number" min="1" step="1" value="${qty}" data-id="${i.id}" aria-label="Quantity for ${name}" style="width:80px">
            </td>
            <td>${fmt(line)}</td>
            <td>
              <button class="btn" data-remove="${i.id}" aria-label="Remove ${name}">Remove</button>
            </td>
          </tr>
        `;
      }).join('');

      if (this.els.tbody) this.els.tbody.innerHTML = rows;

      // Totals
      const subtotal = Cart.subtotal();
      const tax = Math.max(0, subtotal * this.taxRate);
      const total = subtotal + tax;

      if (this.els.subtotal) this.els.subtotal.textContent = fmt(subtotal);
      if (this.els.tax) this.els.tax.textContent = fmt(tax);
      if (this.els.total) this.els.total.textContent = fmt(total);
    }
  };

  window.Tmart.cartPage = cartPage;
})();
