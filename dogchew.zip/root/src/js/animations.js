export function initAnimations(){
  // Load GSAP + ScrollTrigger once
  const gs = 'https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/gsap.min.js';
  const st = 'https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/ScrollTrigger.min.js';
  load(gs).then(()=>load(st)).then(()=>{
    const { gsap, ScrollTrigger } = window; gsap.registerPlugin(ScrollTrigger);

    // Navbar subtle glass shift
    const nav = document.querySelector('header.nav');
    window.addEventListener('scroll', ()=>{ nav.style.backdropFilter = scrollY>20 ? 'blur(14px)' : 'blur(8px)'; }, {passive:true});

    // Hero parallax (GPU transforms only)
    document.querySelectorAll('.hero [data-parallax]').forEach((el,i)=>{
      gsap.to(el,{ y: (i+1)*45, ease:'none',
        scrollTrigger:{ trigger:'.hero', start:'top top', end:'bottom top', scrub:true }
      });
    });

    // Section reveals
    document.querySelectorAll('.reveal').forEach(el=>{
      gsap.from(el,{ opacity:0, y:32, duration:.8, ease:'power2.out',
        scrollTrigger:{ trigger:el, start:'top 85%' }
      });
    });

    // Product card micro hover (shadow and tilt)
    document.querySelectorAll('.product-card').forEach(card=>{
      card.addEventListener('mousemove', (e)=>{
        const r = card.getBoundingClientRect();
        const x = (e.clientX - r.left)/r.width - .5;
        const y = (e.clientY - r.top)/r.height - .5;
        card.style.transform = `translateY(-6px) rotateX(${ -y*4 }deg) rotateY(${ x*4 }deg)`;
      }, {passive:true});
      card.addEventListener('mouseleave', ()=>{ card.style.transform='translateY(0) rotateX(0) rotateY(0)'; });
    });

  });

  // Particle mist background (lightweight, optional)
  const canvas = document.getElementById('mist');
  if(canvas){
    const ctx = canvas.getContext('2d'); let w,h; let parts=[];
    const DPR = Math.min(window.devicePixelRatio||1, 2);
    function resize(){ w=canvas.width=innerWidth*DPR; h=canvas.height=innerHeight*DPR; parts = Array.from({length:50},()=>({
      x:Math.random()*w, y:Math.random()*h, r:10+Math.random()*40, a:.05+.05*Math.random(), vx:(Math.random()-.5)*.2, vy:(Math.random()-.5)*.2
    })); }
    resize(); window.addEventListener('resize',resize);
    function tick(){
      ctx.clearRect(0,0,w,h);
      parts.forEach(p=>{
        ctx.beginPath(); ctx.fillStyle=`rgba(221,233,242,${p.a})`;
        ctx.arc(p.x,p.y,p.r,0,Math.PI*2); ctx.fill();
        p.x+=p.vx; p.y+=p.vy;
        if(p.x<-50) p.x=w+50; if(p.x>w+50) p.x=-50; if(p.y<-50) p.y=h+50; if(p.y>h+50) p.y=-50;
      });
      requestAnimationFrame(tick);
    }
    tick();
  }

  function load(src){ return new Promise(r=>{ const s=document.createElement('script'); s.src=src; s.onload=r; document.head.appendChild(s); });}
}
