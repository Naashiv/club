export async function loadProducts(){
  const res = await fetch('/src/data/products.json', {cache:'no-cache'});
  return res.json();
}
export async function getProductById(id){
  const list = await loadProducts();
  return list.find(p=>p.id===id);
}
