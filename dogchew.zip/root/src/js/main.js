// js/main.js

document.addEventListener('DOMContentLoaded', () => {
  initAuroraEffect();
  initGlassGlow();
  initScrollReveals();
  initAccordion();
  // ... other initializers like cart ...
});

/**
 * Creates a soft, interactive aurora effect in the background that follows the mouse.
 */
function initAuroraEffect() {
  const body = document.body;
  window.addEventListener('mousemove', (e) => {
    requestAnimationFrame(() => {
      body.style.setProperty('--mouse-x', `${e.clientX}px`);
      body.style.setProperty('--mouse-y', `${e.clientY}px`);
    });
  });
}

/**
 * Makes glass panels glow softly where the mouse is hovering over them.
 */
function initGlassGlow() {
  const glassElements = document.querySelectorAll('.glass');
  glassElements.forEach(el => {
    el.addEventListener('mousemove', (e) => {
      const rect = el.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      requestAnimationFrame(() => {
        el.style.setProperty('--mouse-x-local', `${x}px`);
        el.style.setProperty('--mouse-y-local', `${y}px`);
      });
    });
  });
}

/**
 * Uses Intersection Observer to trigger 'reveal-up' animations on scroll.
 * It also adds a stagger effect to grids for a more elegant entrance.
 */
function initScrollReveals() {
  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach((entry, index) => {
      if (entry.isIntersecting) {
        // Apply a delay based on the element's position in the grid
        const delay = entry.target.dataset.staggerDelay || index * 100;
        setTimeout(() => {
          entry.target.classList.add('visible');
        }, delay);
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  // Add the class to all elements you want to animate
  document.querySelectorAll('.reveal-up').forEach(el => observer.observe(el));
}

/**
 * Handles the accordion functionality for the FAQ page.
 */
function initAccordion() {
  document.querySelectorAll('.accordion .q').forEach(button => {
    button.addEventListener('click', () => {
      const item = button.parentElement;
      const isExpanded = item.getAttribute('aria-expanded') === 'true';
      item.setAttribute('aria-expanded', !isExpanded);
    });
  });
}
// Smooth, premium interactions for your home page (and shared behaviors)

document.addEventListener('DOMContentLoaded', () => {
  initAuroraFollow();
  initGlassGlowFollow();
  initScrollReveal();
  initParallaxHint();     // subtle pointer parallax for hero background
  initMistCanvas();       // soft moving mist particles on hero
});

/* 1) Background aurora follows mouse (updates CSS vars on <body>) */
function initAuroraFollow(){
  const body = document.body;
  const move = (x,y)=>{
    body.style.setProperty('--mouse-x', `${x}px`);
    body.style.setProperty('--mouse-y', `${y}px`);
  };
  window.addEventListener('mousemove', (e)=> requestAnimationFrame(()=>move(e.clientX, e.clientY)));
  // Touch fallback: center-ish shimmer
  window.addEventListener('touchmove', (e)=>{
    const t=e.touches[0]; if(!t) return;
    requestAnimationFrame(()=>move(t.clientX, t.clientY));
  }, {passive:true});
}

/* 2) Local glow on any .glass following pointer position */
function initGlassGlowFollow(){
  const els = document.querySelectorAll('.glass');
  els.forEach(el=>{
    el.addEventListener('mousemove', (e)=>{
      const r = el.getBoundingClientRect();
      const x = e.clientX - r.left;
      const y = e.clientY - r.top;
      // Update local CSS variables used by ::after radial gradient
      el.style.setProperty('--local-x', `${x}px`);
      el.style.setProperty('--local-y', `${y}px`);
    });
    el.addEventListener('mouseleave', ()=>{
      el.style.removeProperty('--local-x');
      el.style.removeProperty('--local-y');
    });
  });
}

/* 3) Reveal elements on scroll (works with .reveal class) */
function initScrollReveal(){
  const items = document.querySelectorAll('.reveal');
  if(!items.length) return;
  const io = new IntersectionObserver((entries)=>{
    entries.forEach((entry, idx)=>{
      if(entry.isIntersecting){
        const el = entry.target;
        // Optional stagger using data-stagger or index
        const delay = parseInt(el.getAttribute('data-stagger')|| (idx*80), 10);
        setTimeout(()=> el.classList.add('visible'), Math.max(0, delay));
        io.unobserve(el);
      }
    });
  }, {threshold:.12});
  items.forEach(el=> io.observe(el));
}

/* 4) Subtle pointer-based parallax for hero bg */
function initParallaxHint(){
  const layer = document.querySelector('.hero .parallax');
  if(!layer) return;
  let raf = 0;
  const handle = (x,y)=>{
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(()=>{
      const dx = (x / window.innerWidth - .5) * 2;  // -1..1
      const dy = (y / window.innerHeight - .5) * 2;
      layer.style.transform = `scale(1.08) translate(${dx*1.6}%, ${dy*1.6}%)`;
    });
  };
  window.addEventListener('mousemove', e=> handle(e.clientX, e.clientY));
}

/* 5) Soft mist particles rendered to hero canvas */
function initMistCanvas(){
  const canvas = document.getElementById('mist-canvas');
  if(!canvas) return;
  const ctx = canvas.getContext('2d');
  let w=0, h=0, DPR=Math.min(window.devicePixelRatio||1, 2);
  let particles = [];

  function resize(){
    const rect = canvas.getBoundingClientRect();
    w = canvas.width = Math.floor(rect.width * DPR);
    h = canvas.height = Math.floor(rect.height * DPR);
    particles = Array.from({length: 48}, ()=> ({
      x: Math.random()*w,
      y: Math.random()*h,
      r: 10 + Math.random()*42,
      a: 0.05 + Math.random()*0.08,
      vx: (Math.random()-.5)*0.25,
      vy: (Math.random()-.5)*0.25
    }));
  }
  resize();
  window.addEventListener('resize', resize);

  function tick(){
    ctx.clearRect(0,0,w,h);
    particles.forEach(p=>{
      ctx.beginPath();
      ctx.fillStyle = `rgba(221,233,242,${p.a})`;
      ctx.arc(p.x, p.y, p.r, 0, Math.PI*2);
      ctx.fill();
      p.x += p.vx; p.y += p.vy;
      if(p.x < -60) p.x = w+60;
      if(p.x > w+60) p.x = -60;
      if(p.y < -60) p.y = h+60;
      if(p.y > h+60) p.y = -60;
    });
    requestAnimationFrame(tick);
  }
  tick();
}
