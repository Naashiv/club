export function mountCheckout(){
  // Render cart lines and bind Stripe session creation
  const el = document.querySelector('[data-cart]');
  const subtotal = document.querySelector('[data-subtotal]');
  render();

  document.querySelector('[data-checkout]').addEventListener('click', async ()=>{
    try{
      const res = await fetch('/create-checkout-session',{
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ items: window.Tmart.cart.items().map(i=>({ id:i.id, qty:i.qty })) })
      });
      const data = await res.json();
      if(data.url){ location.href = data.url; } else alert('Checkout failed, please try again.');
    }catch(err){ alert('Network error. Please retry.'); }
  });
m,[xx]
  function render(){
    const lines = window.Tmart.cart.items();
    if(!lines.length){ el.innerHTML='<p class="muted">Your cart is empty.</p>'; subtotal.textContent='$0.00'; return; }
    el.innerHTML = lines.map(l=>`
      <div class="cart-line glass">
        <img src="${l.meta.images[0]}" width="72" height="72" alt="">
        <div><div>${l.meta.name}</div><div class="muted">${l.meta.size} • ${l.meta.flavor}</div></div>
        <div class="qty">
          <button data-dec="${l.id}">-</button>
          <span style="padding:.3rem .7rem">${l.qty}</span>
          <button data-inc="${l.id}">+</button>
        </div>
        <div>$${(l.qty*l.meta.price).toFixed(2)}</div>
        <button aria-label="Remove" data-rem="${l.id}" class="btn">×</button>
      </div>`).join('');
    el.querySelectorAll('[data-inc]').forEach(b=>b.onclick=()=>{Tmart.cart.inc(b.dataset.inc); render();});
    el.querySelectorAll('[data-dec]').forEach(b=>b.onclick=()=>{Tmart.cart.dec(b.dataset.dec); render();});
    el.querySelectorAll('[data-rem]').forEach(b=>b.onclick=()=>{Tmart.cart.remove(b.dataset.rem); render();});
    subtotal.textContent = `$${window.Tmart.cart.subtotal().toFixed(2)}`;
  }
}
