import { initAnimations } from './animations.js';
import { loadProducts, getProductById } from './api.js';
import { Cart } from './cart.js';
import { mountShop } from './product.js';
import { initFilters } from './filters.js';
import { initForms } from './forms.js';
import { setSEO } from './seo.js';

window.Tmart = { cart: new Cart() };

document.addEventListener('DOMContentLoaded', async () => {
  setSEO();
  initAnimations();
  initForms();

  const page = document.body.dataset.page;

  if (page === 'home') {
    // hero parallax already in animations
  }

  if (page === 'shop') {
    const products = await loadProducts();
    mountShop(products);
    initFilters(products);
  }

  if (page === 'product') {
    const params = new URLSearchParams(location.search);
    const id = params.get('id');
    const product = await getProductById(id);
    if (!product) return;
    renderProductDetail(product);
  }

  if (page === 'cart') renderCart();

  if (page === 'checkout') initCheckout();

  if (page === 'faq') initFAQ();

});
/* Renders */
function renderProductDetail(p){
  const name = document.querySelector('[data-p-name]');
  const price = document.querySelector('[data-p-price]');
  const badges = document.querySelector('[data-p-badges]');
  const main = document.querySelector('[data-p-main]');
  const thumbs = document.querySelector('[data-p-thumbs]');
  name.textContent = p.name;
  price.textContent = `$${p.price.toFixed(2)}`;
  badges.innerHTML = p.badges.map(b=>`<span class="tag">${b}</span>`).join('');
  main.src = p.images[0];
  thumbs.innerHTML = p.images.map((src,i)=>`<img src="${src}" class="${i===0?'active':''}" />`).join('');
  thumbs.querySelectorAll('img').forEach(img=>{
    img.addEventListener('click',()=>{
      thumbs.querySelectorAll('img').forEach(x=>x.classList.remove('active'));
      img.classList.add('active'); main.src = img.src;
    });
  });
  document.querySelector('[data-add]').addEventListener('click',()=>{
    Tmart.cart.add(p.id,1,p);
  });
  document.querySelector('[data-buy]').addEventListener('click',()=>{
    Tmart.cart.add(p.id,1,p);
    location.href = '/src/pages/checkout.html';
  });
  // details
  document.querySelector('[data-ingredients]').innerHTML = p.ingredients.join(', ');
  document.querySelector('[data-origin]').textContent = p.origin;
  document.querySelector('[data-benefits]').innerHTML = p.benefits.map(b=>`<li>${b}</li>`).join('');
  const a = p.analysis;
  document.querySelector('[data-analysis]').innerHTML = `
    <tr><td>Protein</td><td>${a.protein}</td></tr>
    <tr><td>Moisture</td><td>${a.moisture}</td></tr>
    <tr><td>Ash</td><td>${a.ash}</td></tr>
    <tr><td>Fat</td><td>${a.fat}</td></tr>
    <tr><td>Fiber</td><td>${a.fiber}</td></tr>`;
}

function renderCart(){
  const el = document.querySelector('[data-cart]');
  const lines = Tmart.cart.items();
  if (!lines.length){ el.innerHTML = `<p class="muted">Your cart is empty.</p>`; return;}
  el.innerHTML = lines.map(l=>`
    <div class="cart-line glass">
      <img src="${l.meta.images[0]}" width="72" height="72" alt="">
      <div>
        <div>${l.meta.name}</div>
        <div class="muted">${l.meta.size} • ${l.meta.flavor}</div>
      </div>
      <div class="qty">
        <button data-dec="${l.id}">-</button>
        <span style="padding:.3rem .7rem">${l.qty}</span>
        <button data-inc="${l.id}">+</button>
      </div>
      <div>$${(l.qty*l.meta.price).toFixed(2)}</div>
      <button aria-label="Remove" data-rem="${l.id}" class="btn">×</button>
    </div>`).join('');
  el.querySelectorAll('[data-inc]').forEach(b=>b.onclick=()=>{Tmart.cart.inc(b.dataset.inc);renderCart();});
  el.querySelectorAll('[data-dec]').forEach(b=>b.onclick=()=>{Tmart.cart.dec(b.dataset.dec);renderCart();});
  el.querySelectorAll('[data-rem]').forEach(b=>b.onclick=()=>{Tmart.cart.remove(b.dataset.rem);renderCart();});
  document.querySelector('[data-subtotal]').textContent = `$${Tmart.cart.subtotal().toFixed(2)}`;
}

async function initCheckout(){
  renderCart();
  document.querySelector('[data-checkout]').addEventListener('click', async ()=>{
    try{
      const res = await fetch('/create-checkout-session',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({items:Tmart.cart.items()})});
      const data = await res.json();
      if(data.url){ location.href = data.url; }
      else alert('Checkout init failed');
    }catch(e){ alert('Network error. Please try again.'); }
  });
}

function initFAQ(){
  document.querySelectorAll('.accordion .item').forEach(it=>{
    const q = it.querySelector('.q'); const a = it.querySelector('.a');
    q.addEventListener('click',()=>{
      const open = a.style.maxHeight && a.style.maxHeight !== '0px';
      a.style.maxHeight = open ? '0px' : a.scrollHeight + 'px';
    });
  });
}
