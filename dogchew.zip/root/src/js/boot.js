import { Cart } from './cart.js';
import { initAnimations } from './animations.js';
import { initForms } from './forms.js';
import { boostPerf } from './perf.js';
import { mountShop } from './shop.js';
import { mountProduct } from './product.js';
import { mountCheckout } from './checkout.js';
import { setSEO } from './seo.js';

window.Tmart = { cart: new Cart() };

document.addEventListener('DOMContentLoaded', ()=>{
  setSEO();
  boostPerf();
  initAnimations();
  initForms();
  window.Tmart.cart.badge();

  const page = document.body.dataset.page;
  if(page==='shop') mountShop();
  if(page==='product') mountProduct();
  if(page==='checkout') mountCheckout();
});
