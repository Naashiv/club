export function setSEO(){
  const d=document;
  meta('viewport','width=device-width, initial-scale=1');
  link('preconnect','https://fonts.googleapis.com');
  link('preconnect','https://fonts.gstatic.com','',true);
  link('stylesheet','https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&family=Playfair+Display:wght@600;700&display=swap');
  meta('description','Authentic Himalayan yak milk dog chews crafted by Sherpa artisans — pure, long-lasting, and loved by dogs worldwide.');
  meta('theme-color','#2D5A4A');
  function meta(name,content){ let m=d.querySelector(`meta[name="${name}"]`); if(!m){m=d.createElement('meta'); m.name=name; d.head.appendChild(m);} m.content=content; }
  function link(rel,href,as='',cross){ const l=d.createElement('link'); l.rel=rel; l.href=href; if(as) l.as=as; if(cross) l.crossOrigin='anonymous'; d.head.appendChild(l); }
}
