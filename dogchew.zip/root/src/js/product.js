import { getProductById } from './api.js';

// Pull the product by id and render a detail view
(async function(){
  const params = new URLSearchParams(location.search);
  const id = params.get('id');
  const mount = document.getElementById('productView');
  if (!id || !mount) { mount.textContent = 'Product not found.'; return; }

  // Reuse the same source as shop (or a shared API)
  const catalog = await loadCatalog();
  const product = catalog.find(p => p.id === id);
  if (!product) { mount.textContent = 'Product not found.'; return; }

  const img = product.images?.[0] || 'assets/images/placeholder.jpg';
  mount.innerHTML = `
    <div class="grid cols-2">
      <div class="glass card">
        <img src="${img}" alt="${product.name}" style="width:100%;border-radius:14px">
      </div>
      <div class="card">
        <h1 class="h2">${product.name}</h1>
        <p class="muted">${product.heritage || ''}</p>
        <p style="margin:.6rem 0 1rem">${product.description || ''}</p>
        <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin:.8rem 0">
          ${(product.features||[]).map(f=>`<span class="tag">${f}</span>`).join('')}
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-top:1rem">
          <strong class="h2" style="font-family:Inter">$${(product.price??0).toFixed(2)} CAD</strong>
          <button id="addDetail" class="btn gold">Add to Cart</button>
        </div>
      </div>
    </div>
  `;

  document.getElementById('addDetail')?.addEventListener('click', ()=>{
    if (window.Tmart?.cart?.add) {
      window.Tmart.cart.add(product.id, 1, product);
      window.Tmart.updateCartBadge?.(window.Tmart.cart.count());
    } else {
      console.warn('Cart API not found.');
    }
  });

  async function loadCatalog(){
    // Option A: If you have an API endpoint, fetch it here
     return fetch('/api/products.json').then(r=>r.json());

    // Option B: Share from sessionStorage captured on shop (simple approach)
    try {
      const cached = JSON.parse(sessionStorage.getItem('tmart_products') || '[]');
      if (cached.length) return cached;
    } catch(e){}

    // Option C: Hard fallback (match your shop data)
    return [
      { id:'chew-xsmall', name:'X-Small Yak Chew', price:1.49, size:'mini', tradition:'classic', images:['assets/images/chew-xsmall.jpg'], heritage:'Classic Himalayan Recipe', features:['30g Weight','For dogs up to 5kg','Bundle Deal'], description:'Bundle: 3 for 3.99 CAD' },
      { id:'chew-small', name:'Small Yak Chew', price:2.49, size:'small', tradition:'classic', images:['assets/images/chew-small.jpg'], heritage:'Classic Himalayan Recipe', features:['50g Weight','For dogs up to 10kg','Bundle Deal'], description:'Bundle: 3 for 6.99 CAD' },
      { id:'chew-medium', name:'Medium Yak Chew', price:3.79, size:'medium', tradition:'classic', images:['assets/images/chew-medium.jpg'], heritage:'Classic Himalayan Recipe', features:['75g Weight','For dogs up to 15kg','Bundle Deal'], description:'Bundle: 3 for 9.99 CAD' },
      { id:'chew-large', name:'Large Yak Chew', price:4.99, size:'large', tradition:'classic', images:['assets/images/chew-large.jpg'], heritage:'Classic Himalayan Recipe', features:['100g Weight','For dogs over 12.5kg','Bundle Deal'], description:'Bundle: 2 for 8.99 CAD' },
      { id:'chew-xlarge', name:'X-Large Yak Chew', price:6.49, size:'xl', tradition:'classic', images:['assets/images/chew-xlarge.jpg'], heritage:'Classic Himalayan Recipe', features:['150g Weight','For dogs over 20kg','Bundle Deal'], description:'Bundle: 2 for 11.99 CAD' }
    ];
  }
})();

