// js/shop.js — safe, resilient shop controller

class ShopManager {
  constructor() {
    // DOM
    this.grid = document.getElementById('productGrid');
    this.loadingState = document.getElementById('loadingState');
    this.emptyState = document.getElementById('emptyState');

    // State
    this.products = [];
    this.filtered = [];
    this.filters = { search: '', size: 'all', tradition: 'all', sort: 'featured' };

    // Boot
    this.init();
  }

  async init() {
    try {
      this.showOnly(this.loadingState);
      await this.loadProducts();
      this.bindControls();
      this.applyFilters();
      this.initSnowEffect();
      // Share products for product.html if used
      try { sessionStorage.setItem('tmart_products', JSON.stringify(this.products)); } catch(e){}
      this.showOnly(this.grid);
    } catch (err) {
      console.error('Shop init failed:', err);
      this.renderError('Failed to load products. Please refresh.');
    }
  }

  async loadProducts() {
    // Replace with real API when available. Safe fallback if API fails.
    try {
      // Example: const res = await fetch('/api/products.json'); this.products = await res.json();
      this.products = [
        { id:'chew-xsmall', name:'X-Small Yak Chew', price:1.49, size:'mini', tradition:'classic', images:['assets/images/chew-xsmall.jpg'], heritage:'Classic Himalayan Recipe', features:['30g','Up to 5kg','Bundle: 3 for 3.99'], description:'Perfect for toy breeds.' },
        { id:'chew-small', name:'Small Yak Chew', price:2.49, size:'small', tradition:'classic', images:['assets/images/chew-small.jpg'], heritage:'Classic Himalayan Recipe', features:['50g','Up to 10kg','Bundle: 3 for 6.99'], description:'Ideal for small dogs (Guelph special).' },
        { id:'chew-medium', name:'Medium Yak Chew', price:3.79, size:'medium', tradition:'classic', images:['assets/images/chew-medium.jpg'], heritage:'Classic Himalayan Recipe', features:['75g','Up to 15kg','Bundle: 3 for 9.99'], description:'Best for medium breeds.' },
        { id:'chew-large', name:'Large Yak Chew', price:4.99, size:'large', tradition:'classic', images:['assets/images/chew-large.jpg'], heritage:'Classic Himalayan Recipe', features:['100g','12.5kg+','Bundle: 2 for 8.99'], description:'Great for strong chewers.' },
        { id:'chew-xlarge', name:'X-Large Yak Chew', price:6.49, size:'xl', tradition:'classic', images:['assets/images/chew-xlarge.jpg'], heritage:'Classic Himalayan Recipe', features:['150g','20kg+','Bundle: 2 for 11.99'], description:'Giant, long-lasting chew.' }
      ];
      // Simulate slight delay
      await new Promise(r => setTimeout(r, 150));
    } catch (e) {
      console.warn('Product API failed, loading fallback.', e);
      this.products = [];
    }
  }

  bindControls() {
    const search = document.getElementById('productSearch');
    const sizeFilters = document.getElementById('sizeFilters');
    const traditionFilters = document.getElementById('traditionFilters');
    const sort = document.getElementById('productSort');

    search?.addEventListener('input', (e) => {
      this.filters.search = (e.target.value || '').toLowerCase().trim();
      this.applyFilters();
    });

    sizeFilters?.addEventListener('click', (e) => {
      const btn = e.target.closest('.pill');
      if (!btn) return;
      sizeFilters.querySelectorAll('.pill').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      this.filters.size = btn.dataset.filter || 'all';
      this.applyFilters();
    });

    traditionFilters?.addEventListener('click', (e) => {
      const btn = e.target.closest('.pill');
      if (!btn) return;
      traditionFilters.querySelectorAll('.pill').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      this.filters.tradition = btn.dataset.filter || 'all';
      this.applyFilters();
    });

    sort?.addEventListener('change', (e) => {
      this.filters.sort = e.target.value || 'featured';
      this.applyFilters();
    });
  }

  applyFilters() {
    try {
      const { search, size, tradition, sort } = this.filters;
      let list = [...this.products];

      if (search) {
        list = list.filter(p => {
          const fields = [
            p.name, p.heritage, p.description, p.size, p.tradition
          ].map(v => String(v || '').toLowerCase());
          return fields.some(v => v.includes(search));
        });
      }
      if (size !== 'all') list = list.filter(p => p.size === size);
      if (tradition !== 'all') list = list.filter(p => p.tradition === tradition);

      if (sort === 'name') list.sort((a,b)=> String(a.name).localeCompare(String(b.name)));
      if (sort === 'price-low') list.sort((a,b)=> (a.price||0) - (b.price||0));
      if (sort === 'price-high') list.sort((a,b)=> (b.price||0) - (a.price||0));
      if (sort === 'tradition') list.sort((a,b)=> String(a.tradition||'').localeCompare(String(b.tradition||'')));

      this.filtered = list;
      this.render();
    } catch (e) {
      console.error('Filter error:', e);
      this.renderError('Something went wrong while filtering.');
    }
  }

  render() {
    if (!this.grid) return;
    if (!this.filtered.length) {
      this.grid.innerHTML = '';
      this.showOnly(this.emptyState);
      return;
    }

    const html = this.filtered.map(p => {
      const img = (p.images && p.images[0]) ? p.images[0] : 'assets/images/placeholder.jpg';
      const features = Array.isArray(p.features) ? p.features : [];
      return `
        <article class="product-card glass reveal-up" data-id="${this.escape(p.id)}">
          <div class="product-image">
            <img src="${this.escape(img)}" alt="${this.escape(p.name)}">
            ${p.badge ? `<span class="product-badge">${this.escape(p.badge)}</span>` : ''}
          </div>
          <div class="product-info">
            <h4 class="product-title">${this.escape(p.name)}</h4>
            <p class="product-heritage">${this.escape(p.heritage || '')}</p>
            <div class="product-features">
              ${features.map(f => `<span class="feature-tag">${this.escape(f)}</span>`).join('')}
            </div>
            <p class="product-price">$${(p.price ?? 0).toFixed(2)} CAD</p>
            <p class="muted" style="font-size: 0.8rem; margin-top: -0.5rem;">${this.escape(p.description || '')}</p>
            <div class="product-actions">
              <button class="btn-add-cart">Add to Cart</button>
              <button class="btn-view-details">View Details</button>
            </div>
          </div>
        </article>
      `;
    }).join('');

    this.grid.innerHTML = html;
    this.showOnly(this.grid);
    this.bindCardEvents();
  }

  bindCardEvents() {
    // Add to cart
    this.grid.querySelectorAll('.btn-add-cart').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const card = btn.closest('[data-id]');
        const id = card?.dataset.id;
        const prod = this.products.find(x => x.id === id);
        if (!prod) return;
        if (window.Tmart?.cart?.add) {
          window.Tmart.cart.add(prod.id, 1, prod);
          window.Tmart.updateCartBadge?.(window.Tmart.cart.count());
        } else {
          console.warn('Cart not initialized (window.Tmart.cart.add missing).');
        }
      });
    });

    // View details button
    this.grid.querySelectorAll('.btn-view-details').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const card = btn.closest('[data-id]');
        const id = card?.dataset.id;
        this.goToProduct(id, card);
      });
    });

    // Card click
    this.grid.querySelectorAll('.product-card').forEach(card => {
      card.addEventListener('click', (e) => {
        if (e.target.closest('button')) return;
        const id = card.dataset.id;
        this.goToProduct(id, card);
      });
    });
  }

  goToProduct(id, card) {
    if (!id) return;
    try { sessionStorage.setItem('tmart_last_card_id', id); } catch(e){}
    if (window.cardToProductTransition && card) {
      try { window.cardToProductTransition(card); } catch(e){ console.warn('Transition failed', e); }
    }
    // Ensure the path is correct relative to shop.html
    // If product.html is in the same folder as shop.html, this is fine:
    location.href = 'product.html?id=' + encodeURIComponent(id);
  }

  renderError(msg) {
    if (this.grid) this.grid.innerHTML = '';
    if (this.emptyState) this.emptyState.innerHTML = `
      <div class="empty-state glass">
        <h3>${this.escape(msg)}</h3>
        <p>Please try again later.</p>
      </div>
    `;
    this.showOnly(this.emptyState);
  }

  showOnly(elementToShow) {
    [this.grid, this.loadingState, this.emptyState].forEach(el => {
      if (!el) return;
      el.style.display = 'none';
    });
    if (elementToShow) {
      const isGrid = elementToShow === this.grid;
      elementToShow.style.display = isGrid ? 'grid' : 'block';
    }
  }

  escape(str) {
    return String(str || '')
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
  }

  // Optional atmospheric effect
  initSnowEffect() {
    const canvas = document.getElementById('snow-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let w, h, DPR = Math.min(window.devicePixelRatio || 1, 2);
    let flakes = [];

    function resize() {
      const rect = canvas.getBoundingClientRect();
      w = canvas.width = Math.floor(rect.width * DPR);
      h = canvas.height = Math.floor(rect.height * DPR);
      flakes = Array.from({ length: 60 }, () => ({
        x: Math.random() * w, y: Math.random() * h, r: 1 + Math.random() * 2, s: 0.3 + Math.random() * 0.8, d: (Math.random()-0.5)*0.4
      }));
    }
    resize(); window.addEventListener('resize', resize);

    (function tick(){
      ctx.clearRect(0,0,w,h);
      ctx.fillStyle = 'rgba(255,255,255,0.8)';
      for (const f of flakes) {
        ctx.beginPath(); ctx.arc(f.x, f.y, f.r, 0, Math.PI*2); ctx.fill();
        f.y += f.s; f.x += f.d;
        if (f.y > h+5) { f.y = -5; f.x = Math.random()*w; }
        if (f.x < -5) f.x = w+5; if (f.x > w+5) f.x = -5;
      }
      requestAnimationFrame(tick);
    })();
  }
}

// Boot after DOM ready
document.addEventListener('DOMContentLoaded', () => new ShopManager());
