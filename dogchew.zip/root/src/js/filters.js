import { loadProducts } from './api.js';

export function initFilters(products){
  const controls = document.querySelector('[data-controls]');
  const search = document.querySelector('[data-search]');
  const sortSel = document.querySelector('[data-sort]');

  controls.addEventListener('click',(e)=>{
    const pill = e.target.closest('.pill'); if(!pill) return;
    pill.classList.toggle('active');
    apply();
  });
  search.addEventListener('input',debounce(apply,200));
  sortSel.addEventListener('change',apply);

  function apply(){
    const active = [...controls.querySelectorAll('.pill.active')].map(p=>p.dataset.f);
    let list=[...products];
    if (active.includes('S') || active.includes('M') || active.includes('L')) {
      list = list.filter(p=>active.includes(p.size));
    }
    const q = search.value.toLowerCase().trim();
    if(q) list = list.filter(p=>p.name.toLowerCase().includes(q));
    const s = sortSel.value;
    if(s==='price-asc') list.sort((a,b)=>a.price-b.price);
    if(s==='price-desc') list.sort((a,b)=>b.price-a.price);
    if(s==='name') list.sort((a,b)=>a.name.localeCompare(b.name));
    window.renderProducts(list);
  }
  function debounce(fn,ms){let t;return(...a)=>{clearTimeout(t);t=setTimeout(()=>fn(...a),ms)}}
}
